public class Inventory
{
    public UUID id;
    public List<Item> items;
}