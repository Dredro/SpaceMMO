public abstract class Item
{
    public UUID id;
    public string name;

    public void Use()
    {

    }
    public void Drop()
    {

    }
    public void PickUp()
    {
        
    }
}