public class UIEnergy : IObserver
{
    
    public void Notify()
    {
        throw new NotImplementedException();
    }
}