public class UIHealth : IObserver
{
    
    public void Notify()
    {
        throw new NotImplementedException();
    }
}