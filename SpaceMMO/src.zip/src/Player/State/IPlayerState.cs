public interface IPlayerState
{
    public void DoAction();
}