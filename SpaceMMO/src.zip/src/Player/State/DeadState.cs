public class DeadState : IPlayerState
{
    public void DoAction()
    {
        throw new NotImplementedException();
    }
}