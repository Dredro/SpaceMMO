public class AliveState : IPlayerState
{
    public void DoAction()
    {
        throw new NotImplementedException();
    }
}