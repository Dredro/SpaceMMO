public class TiredState : IPlayerState
{
    public void DoAction()
    {
        throw new NotImplementedException();
    }
}