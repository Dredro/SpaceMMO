public class UUID{
    public string id;
    public UUID(byte[] data)
    {
        //to implement
    }
}