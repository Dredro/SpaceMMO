public class BaseArmor:Armor
{
    
}