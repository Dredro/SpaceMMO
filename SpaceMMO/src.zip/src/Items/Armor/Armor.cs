public abstract class Armor: Item
{

}