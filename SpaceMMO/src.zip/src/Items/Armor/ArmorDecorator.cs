public abstract class ArmorDecorator:Armor
{

}