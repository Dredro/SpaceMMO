public class FireResistanceDecorator: ArmorDecorator
{

}