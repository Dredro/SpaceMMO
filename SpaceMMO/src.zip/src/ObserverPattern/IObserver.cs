public interface IObserver
{
    public void Notify();
}